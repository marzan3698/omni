export declare const exampleService: {
    getExampleData: () => Promise<{
        message: string;
        timestamp: string;
    }>;
};
//# sourceMappingURL=example.service.d.ts.map