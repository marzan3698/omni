import { Request, Response } from 'express';
export declare const exampleController: {
    getExample: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
};
//# sourceMappingURL=example.controller.d.ts.map