import multer from 'multer';
import path from 'path';
import fs from 'fs';
// Create uploads directory if it doesn't exist
const uploadsDir = path.join(process.cwd(), 'uploads', 'products');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}
// Configure storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
        // Generate unique filename: timestamp-random-originalname
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        const ext = path.extname(file.originalname);
        const name = path.basename(file.originalname, ext);
        cb(null, `${name}-${uniqueSuffix}${ext}`);
    },
});
// File filter - only images
const fileFilter = (req, file, cb) => {
    const allowedMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (allowedMimes.includes(file.mimetype)) {
        cb(null, true);
    }
    else {
        cb(new Error('Invalid file type. Only JPEG, PNG, GIF, and WebP images are allowed.'));
    }
};
// Configure multer
export const uploadProductImage = multer({
    storage,
    fileFilter,
    limits: {
        fileSize: 5 * 1024 * 1024, // 5MB limit
    },
});
// Single file upload middleware
export const singleProductImage = uploadProductImage.single('image');
// ============================================
// Social Messages Image Upload
// ============================================
// Create uploads directory for social messages if it doesn't exist
const socialUploadsDir = path.join(process.cwd(), 'uploads', 'social');
if (!fs.existsSync(socialUploadsDir)) {
    fs.mkdirSync(socialUploadsDir, { recursive: true });
}
// Configure storage for social messages
const socialStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, socialUploadsDir);
    },
    filename: (req, file, cb) => {
        // Generate unique filename: timestamp-random-originalname
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        const ext = path.extname(file.originalname);
        // Sanitize filename - remove special characters
        const name = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9]/g, '_');
        cb(null, `${name}-${uniqueSuffix}${ext}`);
    },
});
// File filter for social messages - only images
const socialFileFilter = (req, file, cb) => {
    console.log('🔍 File filter check:', {
        filename: file.originalname,
        mimetype: file.mimetype,
        fieldname: file.fieldname,
    });
    const allowedMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (allowedMimes.includes(file.mimetype)) {
        console.log('✅ File type allowed:', file.mimetype);
        cb(null, true);
    }
    else {
        console.error('❌ File type rejected:', file.mimetype);
        cb(new Error(`Invalid file type: ${file.mimetype}. Only JPEG, PNG, GIF, and WebP images are allowed.`));
    }
};
// Configure multer for social messages
export const uploadSocialImage = multer({
    storage: socialStorage,
    fileFilter: socialFileFilter,
    limits: {
        fileSize: 5 * 1024 * 1024, // 5MB limit
    },
});
// Single file upload middleware for social messages
export const singleSocialImage = uploadSocialImage.single('image');
// ============================================
// Theme Logo Upload
// ============================================
// Create uploads directory for theme logo if it doesn't exist
const themeUploadsDir = path.join(process.cwd(), 'uploads', 'theme');
if (!fs.existsSync(themeUploadsDir)) {
    fs.mkdirSync(themeUploadsDir, { recursive: true });
}
// Configure storage for theme logo
const themeStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, themeUploadsDir);
    },
    filename: (req, file, cb) => {
        // Generate unique filename: logo-timestamp-random.ext
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        const ext = path.extname(file.originalname);
        cb(null, `logo-${uniqueSuffix}${ext}`);
    },
});
// File filter for theme logo - only images (including SVG)
const themeFileFilter = (req, file, cb) => {
    const allowedMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
    if (allowedMimes.includes(file.mimetype)) {
        cb(null, true);
    }
    else {
        cb(new Error('Invalid file type. Only JPEG, PNG, GIF, WebP, and SVG images are allowed.'));
    }
};
// Configure multer for theme logo
export const uploadThemeLogo = multer({
    storage: themeStorage,
    fileFilter: themeFileFilter,
    limits: {
        fileSize: 2 * 1024 * 1024, // 2MB limit
    },
});
// Single file upload middleware for theme logo
export const singleThemeLogo = uploadThemeLogo.single('logo');
// ============================================
// Task Attachments Upload (Images, PDFs, Videos, Audio)
// ============================================
// Create uploads directory for task attachments if it doesn't exist
const taskUploadsBaseDir = path.join(process.cwd(), 'uploads', 'tasks');
if (!fs.existsSync(taskUploadsBaseDir)) {
    fs.mkdirSync(taskUploadsBaseDir, { recursive: true });
}
// Configure storage for task attachments
// Note: Destination will be set dynamically based on taskId or subTaskId in the request
const taskStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        // Get taskId or subTaskId from request body/params
        // Note: route uses :id, so check req.params.id first, then req.params.taskId
        const taskId = (req.params?.id || req.body?.taskId || req.params?.taskId || req.query?.taskId);
        const subTaskId = (req.body?.subTaskId || req.params?.subTaskId || req.query?.subTaskId);
        let uploadDir;
        if (taskId) {
            uploadDir = path.join(taskUploadsBaseDir, `task-${taskId}`, 'attachments');
        }
        else if (subTaskId) {
            uploadDir = path.join(taskUploadsBaseDir, `subtask-${subTaskId}`, 'attachments');
        }
        else {
            // Fallback to a temporary directory if no task/subtask ID provided
            uploadDir = path.join(taskUploadsBaseDir, 'temp');
        }
        // Create directory if it doesn't exist
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        // Generate unique filename: timestamp-random-sanitized-originalname
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        const ext = path.extname(file.originalname);
        // Sanitize filename - remove special characters but keep spaces and hyphens
        const name = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9\s-_]/g, '_');
        cb(null, `${name}-${uniqueSuffix}${ext}`);
    },
});
// File filter for task attachments - supports images, PDFs, videos, and audio
const taskFileFilter = (req, file, cb) => {
    // Define allowed MIME types for task attachments
    const allowedMimes = [
        // Images
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/webp',
        // PDFs
        'application/pdf',
        // Videos
        'video/mp4',
        'video/mpeg',
        'video/quicktime',
        'video/x-msvideo',
        'video/webm',
        // Audio
        'audio/mpeg',
        'audio/mp3',
        'audio/wav',
        'audio/x-wav',
        'audio/ogg',
        'audio/webm',
        'audio/aac',
        'audio/flac',
    ];
    if (allowedMimes.includes(file.mimetype)) {
        cb(null, true);
    }
    else {
        cb(new Error(`Invalid file type: ${file.mimetype}. Allowed types: Images (JPEG, PNG, GIF, WebP), PDFs, Videos (MP4, WebM, AVI, MOV), Audio (MP3, WAV, OGG, WebM, AAC, FLAC).`));
    }
};
// Configure multer for task attachments
export const uploadTaskAttachment = multer({
    storage: taskStorage,
    fileFilter: taskFileFilter,
    limits: {
        fileSize: 50 * 1024 * 1024, // 50MB limit (for videos)
    },
});
// Single file upload middleware for task attachments
export const singleTaskAttachment = uploadTaskAttachment.single('file');
// Multiple files upload middleware for task attachments
export const multipleTaskAttachments = uploadTaskAttachment.array('files', 10); // Max 10 files at once
//# sourceMappingURL=upload.js.map