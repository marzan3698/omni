declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=productCategory.routes.d.ts.map