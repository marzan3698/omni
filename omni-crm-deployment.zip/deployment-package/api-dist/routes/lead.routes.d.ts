declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=lead.routes.d.ts.map