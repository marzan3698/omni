declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=employeeGroup.routes.d.ts.map