declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=chatwoot.routes.d.ts.map