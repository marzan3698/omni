declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=integration.routes.d.ts.map