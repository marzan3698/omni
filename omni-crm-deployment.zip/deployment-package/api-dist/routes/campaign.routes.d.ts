declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=campaign.routes.d.ts.map