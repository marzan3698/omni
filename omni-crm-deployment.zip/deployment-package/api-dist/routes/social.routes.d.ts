declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=social.routes.d.ts.map