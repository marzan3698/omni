declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=public.routes.d.ts.map