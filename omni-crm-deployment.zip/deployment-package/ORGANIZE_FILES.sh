#!/bin/bash
# cPanel File Organization Script
# Run this in cPanel Terminal after extracting ZIP file

echo "📁 Organizing files for cPanel deployment..."

# Navigate to public_html
cd ~/public_html

# Create api directory if it doesn't exist
mkdir -p api

# Move backend files to api directory
echo "Moving backend files..."
mv api-dist api/dist 2>/dev/null || echo "api-dist already moved or doesn't exist"
mv api-prisma api/prisma 2>/dev/null || echo "api-prisma already moved or doesn't exist"
mv api-package.json api/package.json 2>/dev/null || echo "api-package.json already moved or doesn't exist"
mv api-package-lock.json api/package-lock.json 2>/dev/null || echo "api-package-lock.json already moved or doesn't exist"
mv api-uploads api/uploads 2>/dev/null || echo "api-uploads already moved or doesn't exist"

# Move frontend files to root
echo "Moving frontend files to root..."
if [ -d "frontend-dist" ]; then
    cp -r frontend-dist/* .
    cp -r frontend-dist/.* . 2>/dev/null || true
    rm -rf frontend-dist
    echo "✅ Frontend files moved to root"
else
    echo "⚠️ frontend-dist folder not found"
fi

# Clean up
echo "Cleaning up..."
rm -f DEPLOYMENT_INSTRUCTIONS.md 2>/dev/null || true

# Set permissions
echo "Setting file permissions..."
chmod 755 api
chmod 755 api/uploads
chmod 644 api/package.json

echo ""
echo "✅ File organization complete!"
echo ""
echo "📁 Final structure:"
echo "  public_html/"
echo "    ├── api/"
echo "    │   ├── dist/"
echo "    │   ├── prisma/"
echo "    │   ├── package.json"
echo "    │   ├── package-lock.json"
echo "    │   └── uploads/"
echo "    ├── index.html"
echo "    └── assets/"
echo ""
echo "Next steps:"
echo "1. Node.js App Setup in cPanel"
echo "2. Install dependencies: cd ~/public_html/api && npm install --production"
echo "3. Generate Prisma client: npx prisma generate"
echo "4. Configure environment variables"
echo "5. Start Node.js app"
