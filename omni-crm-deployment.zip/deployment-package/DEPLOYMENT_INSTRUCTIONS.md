# cPanel Deployment Instructions for www.paaera.com

## 📦 Package Contents

এই package-এ আছে:
- `frontend-dist/` - Frontend build files (React app)
- `api-dist/` - Backend build files (Node.js app)
- `api-prisma/` - Database schema and migrations
- `api-package.json` - Backend dependencies list
- `api-package-lock.json` - Locked dependency versions
- `api-uploads/` - Empty uploads folder

## 📁 cPanel-এ File Organization

### Step 1: Extract ZIP File

1. cPanel File Manager-এ `public_html` folder-এ যান
2. `omni-crm-deployment.zip` upload করুন
3. Extract করুন

### Step 2: Organize Files

Extract করার পর এই structure তৈরি করুন:

```
public_html/
├── api/                    # Backend (Node.js app)
│   ├── dist/              # api-dist থেকে copy করুন
│   ├── prisma/            # api-prisma থেকে copy করুন
│   ├── package.json       # api-package.json rename করুন
│   ├── package-lock.json  # api-package-lock.json rename করুন
│   └── uploads/            # api-uploads থেকে copy করুন
│
└── [root]/                 # Frontend
    ├── index.html         # frontend-dist থেকে
    ├── assets/            # frontend-dist/assets থেকে
    └── ... (all from frontend-dist/)
```

### Step 3: Commands to Run

cPanel Terminal-এ এই commands run করুন:

```bash
# Navigate to public_html
cd ~/public_html

# Rename and organize backend files
mv deployment-package/api-dist api/dist
mv deployment-package/api-prisma api/prisma
mv deployment-package/api-package.json api/package.json
mv deployment-package/api-package-lock.json api/package-lock.json
mv deployment-package/api-uploads api/uploads

# Move frontend files to root
cp -r deployment-package/frontend-dist/* .

# Clean up
rm -rf deployment-package
```

## ⚙️ Next Steps

1. Node.js App Setup করুন (cPanel-এ)
2. Dependencies Install করুন
3. Environment Variables Set করুন
4. Installation Wizard Access করুন

## 🔗 Important URLs

- Frontend: `https://www.paaera.com`
- Backend API: `https://api.paaera.com` (subdomain setup করতে হবে)
